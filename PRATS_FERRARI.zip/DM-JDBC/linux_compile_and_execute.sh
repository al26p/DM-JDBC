java  -classpath .:mysql-connector-java-5.1.38-bin.jar Main
